import { subjects, quizzes } from './data.js';
import './style.css';

const STORAGE_KEY = 'omnisora-state-v1';
const LEGACY_PROGRESS_KEY = 'omniscient-progress';
const LEGACY_COMPLETED_KEY = 'completed';

const $ = (selector, root = document) => root.querySelector(selector);
const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
}[char]));

function readJson(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : JSON.parse(value);
  } catch {
    return fallback;
  }
}

function loadSavedState() {
  const saved = readJson(STORAGE_KEY, {});
  const legacy = readJson(LEGACY_PROGRESS_KEY, {});
  const legacyCompleted = readJson(LEGACY_COMPLETED_KEY, []);

  const answers = saved.answers ?? legacy.answers ?? {};
  const completed = saved.completed ?? legacy.completed ?? legacyCompleted;
  const theme = saved.theme ?? localStorage.getItem('theme');

  return {
    answers: answers && typeof answers === 'object' && !Array.isArray(answers) ? answers : {},
    completed: Array.isArray(completed) ? completed.filter((item) => typeof item === 'string') : [],
    theme: theme === 'light' ? 'light' : 'dark',
  };
}

const saved = loadSavedState();
const state = {
  tab: 'Науки',
  subject: null,
  topic: null,
  query: '',
  quiz: 0,
  answers: saved.answers,
  completed: saved.completed,
  theme: saved.theme,
};

const app = $('#app');

function save() {
  const snapshot = {
    answers: state.answers,
    completed: state.completed,
    theme: state.theme,
    updatedAt: new Date().toISOString(),
  };

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    // Keep old keys readable during the transition from the starter version.
    localStorage.setItem(LEGACY_COMPLETED_KEY, JSON.stringify(state.completed));
    localStorage.setItem('theme', state.theme);
    return true;
  } catch (error) {
    console.warn('Не удалось сохранить прогресс на этом устройстве:', error);
    return false;
  }
}

function header() {
  return `
    <header>
      <div class="brand">
        <div class="logo" aria-hidden="true">Ω</div>
        <div><b>OMNISORA</b><small>ЕДИНАЯ СРЕДА НАУЧНЫХ ЗНАНИЙ</small></div>
      </div>
      <button class="ghost" id="theme" type="button" aria-label="Переключить тему">
        ${state.theme === 'dark' ? '☀' : '☾'}
      </button>
    </header>`;
}

const navIcons = {
  Науки: '◈',
  Карта: '⌘',
  Практика: '✓',
  Библиотека: '▤',
  Профиль: '◎',
  'ИИ-наставник': '✧',
};

function nav() {
  return `<nav aria-label="Основная навигация">${Object.keys(navIcons).map((label) => `
    <button type="button" class="${state.tab === label ? 'active' : ''}"
      data-tab="${label}" ${state.tab === label ? 'aria-current="page"' : ''}>
      ${navIcons[label]}<span>${label}</span>
    </button>`).join('')}</nav>`;
}

function home() {
  const query = state.query.trim().toLocaleLowerCase('ru');
  const filtered = subjects.filter((subject) => {
    const searchable = [
      subject.name,
      subject.desc,
      ...subject.topics.flatMap((topic) => [topic.title, topic.body, ...topic.facts]),
    ].join(' ').toLocaleLowerCase('ru');
    return searchable.includes(query);
  });

  return `
    <section class="hero">
      <p class="eyebrow">ЕДИНАЯ СРЕДА ЗНАНИЙ</p>
      <h1>Исследуй <em>всё.</em><br>Понимай глубже.</h1>
      <p class="muted">Фундаментальные науки, взаимосвязи и знания — в одном пространстве.</p>
      <input id="search" type="search" autocomplete="off"
        aria-label="Поиск по наукам и учебным темам"
        placeholder="⌕  Найти дисциплину или тему..." value="${escapeHtml(state.query)}">
    </section>
    <div class="section-head">
      <div><p class="eyebrow">НАУЧНЫЕ ДИСЦИПЛИНЫ</p><h2>Каталог наук</h2></div>
      <span class="count">${filtered.length} из ${subjects.length} дисциплин</span>
    </div>
    <div class="grid">
      ${filtered.map((subject) => `
        <button class="subject" type="button" data-sub="${escapeHtml(subject.id)}"
          style="--accent:${escapeHtml(subject.color)}">
          <span class="subject-icon" aria-hidden="true">${escapeHtml(subject.icon)}</span>
          <b>${escapeHtml(subject.name)}</b>
          <small>${escapeHtml(subject.desc)}</small>
          <span class="submeta">${subject.topics.length} учебных тем <i>↗</i></span>
        </button>`).join('')}
      ${filtered.length ? '' : '<p class="note empty-state">По этому запросу ничего не найдено. Попробуй изменить формулировку.</p>'}
    </div>`;
}

function subjectPage() {
  const selected = subjects.find((item) => item.id === state.subject);
  if (!selected) {
    state.subject = null;
    state.topic = null;
    return home();
  }

  return `
    <button class="back" id="back" type="button">← Все науки</button>
    <div class="subject-hero" style="--accent:${escapeHtml(selected.color)}">
      <span class="subject-icon" aria-hidden="true">${escapeHtml(selected.icon)}</span>
      <p class="eyebrow">НАУЧНАЯ ДИСЦИПЛИНА</p>
      <h1>${escapeHtml(selected.name)}</h1>
      <p class="muted">${escapeHtml(selected.desc)}</p>
    </div>
    <h2>Учебная программа</h2>
    <div class="topics">${selected.topics.map((topic, index) => `
      <button class="topic" type="button" data-topic="${index}">
        <span class="num">${String(index + 1).padStart(2, '0')}</span>
        <span><b>${escapeHtml(topic.title)}</b>
          <small>${escapeHtml(topic.level)} · ${state.completed.includes(`${selected.id}:${index}`) ? 'Изучено ✓' : 'Учебный материал'}</small>
        </span>
        <i aria-hidden="true">→</i>
      </button>`).join('')}</div>`;
}

function lessonPage() {
  const selected = subjects.find((item) => item.id === state.subject);
  const topic = selected?.topics[state.topic];
  if (!selected || !topic) {
    state.topic = null;
    state.subject = null;
    return home();
  }

  const key = `${selected.id}:${state.topic}`;
  const isCompleted = state.completed.includes(key);

  return `
    <button class="back" id="back" type="button">← ${escapeHtml(selected.name)}</button>
    <p class="eyebrow">${escapeHtml(selected.name.toLocaleUpperCase('ru'))} · ${escapeHtml(topic.level.toLocaleUpperCase('ru'))}</p>
    <h1 class="lesson-title">${escapeHtml(topic.title)}</h1>
    <article class="lesson">
      <p>${escapeHtml(topic.body)}</p>
      <h3>Ключевые положения</h3>
      <ul>${topic.facts.map((fact) => `<li>${escapeHtml(fact)}</li>`).join('')}</ul>
      <div class="note">Это вводный учебный конспект. Для углублённого изучения нужны профильные учебники, проверяемые научные публикации и первичные источники.</div>
    </article>
    <button class="primary" id="done" type="button">
      ${isCompleted ? 'Тема уже отмечена ✓' : 'Отметить тему изученной ✓'}
    </button>`;
}

function practicePage() {
  const question = quizzes[state.quiz];
  if (!question) return '<p class="note">Вопросы пока не добавлены.</p>';

  const selectedAnswer = state.answers[state.quiz];
  const hasAnswered = selectedAnswer !== undefined;

  return `
    <p class="eyebrow">ЗАКРЕПЛЕНИЕ ЗНАНИЙ</p>
    <h1>Практика</h1>
    <p class="muted">Короткая проверка базовых научных понятий.</p>
    <div class="quiz">
      <div class="quiztop">ВОПРОС ${state.quiz + 1} ИЗ ${quizzes.length}</div>
      <h2>${escapeHtml(question.q)}</h2>
      <div class="answers">${question.a.map((answer, index) => `
        <button type="button" data-answer="${index}"
          class="${selectedAnswer === index ? 'chosen' : ''}"
          ${hasAnswered ? 'disabled' : ''}>
          ${escapeHtml(answer)}
        </button>`).join('')}</div>
      ${hasAnswered ? `<p class="explain">${selectedAnswer === question.correct ? 'Верно!' : 'Пока неверно.'} ${escapeHtml(question.explain)}</p>` : ''}
      <button class="primary" id="next" type="button" ${!hasAnswered ? 'disabled' : ''}>
        ${state.quiz === quizzes.length - 1 ? 'К первому вопросу' : 'Следующий вопрос'} →
      </button>
    </div>`;
}

function libraryPage() {
  const completedLessons = subjects.flatMap((subject) => subject.topics.map((topic, index) => ({
    subject, topic, index,
  }))).filter(({ subject, index }) => state.completed.includes(`${subject.id}:${index}`));

  return `
    <p class="eyebrow">ЛИЧНАЯ КОЛЛЕКЦИЯ</p>
    <h1>Библиотека</h1>
    <p class="muted">Отмеченные темы и учебный прогресс хранятся на этом устройстве.</p>
    <div class="topics">
      ${completedLessons.map(({ subject, topic, index }) => `
        <button class="topic" type="button" data-sub="${escapeHtml(subject.id)}" data-topic="${index}">
          <span><b>${escapeHtml(subject.name)}: ${escapeHtml(topic.title)}</b><small>✓ Изучено</small></span>
          <i aria-hidden="true">→</i>
        </button>`).join('') || '<p class="note">Пока нет завершённых тем. Открой дисциплину и отметь изученный материал.</p>'}
    </div>`;
}

function profilePage() {
  const answeredCount = Object.keys(state.answers).filter((index) => Number.isInteger(Number(index))).length;
  const totalTopics = subjects.reduce((total, subject) => total + subject.topics.length, 0);
  const percent = totalTopics ? Math.round((state.completed.length / totalTopics) * 100) : 0;

  return `
    <p class="eyebrow">ТВОЁ ОБУЧЕНИЕ</p>
    <h1>Профиль</h1>
    <div class="quiz">
      <h2>Прогресс обучения</h2>
      <p>Завершено тем: <b>${state.completed.length}</b> из ${totalTopics}</p>
      <p>Прогресс программы: <b>${percent}%</b></p>
      <p>Вопросов с ответами: <b>${answeredCount}</b> из ${quizzes.length}</p>
      <div class="progress-track" role="progressbar" aria-label="Прогресс изучения тем"
        aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}">
        <span style="width:${percent}%"></span>
      </div>
      <p class="muted">Данные сохраняются локально в браузере. Сейчас синхронизации между устройствами и учётных записей нет.</p>
    </div>`;
}

function mapPage() {
  return `
    <p class="eyebrow">СВЯЗИ ЗНАНИЙ</p>
    <h1>Карта наук</h1>
    <p class="muted">Выбери дисциплину, чтобы перейти к её учебной программе.</p>
    <div class="mapnodes">${subjects.map((subject) => `
      <button type="button" data-sub="${escapeHtml(subject.id)}"
        style="--accent:${escapeHtml(subject.color)}">
        ${escapeHtml(subject.icon)} ${escapeHtml(subject.name)}
      </button>`).join('')}</div>
    <p class="note">Полноценный граф междисциплинарных связей ещё предстоит разработать.</p>`;
}

function assistantPage() {
  return `
    <p class="eyebrow">ПЕРСОНАЛЬНЫЙ ПОМОЩНИК</p>
    <h1>ИИ-наставник</h1>
    <p class="muted">Задавай вопросы, проси объяснить сложную тему проще или составить план изучения.</p>
    <section class="assistant-panel" aria-label="Чат с ИИ-наставником">
      <div id="assistant-messages" class="assistant-messages" aria-live="polite">
        <div class="assistant-message assistant">Привет! Я помогу разобраться в научных вопросах. Могу объяснить тему на нескольких уровнях сложности, привести примеры или проверить понимание.</div>
      </div>
      <form id="assistant-form" class="assistant-form">
        <label class="sr-only" for="assistant-prompt">Твой вопрос</label>
        <textarea id="assistant-prompt" rows="3" maxlength="6000" placeholder="Например: объясни квантовую запутанность простыми словами..."></textarea>
        <button class="primary" type="submit" id="assistant-send">Отправить ↗</button>
      </form>
      <p class="note" id="assistant-status">Подключение ИИ ещё не настроено. Для безопасности ключ модели должен храниться на сервере, а не в приложении.</p>
    </section>`;
}

function render() {
  document.documentElement.dataset.theme = state.theme;

  let content;
  if (state.topic !== null) content = lessonPage();
  else if (state.subject !== null) content = subjectPage();
  else if (state.tab === 'Практика') content = practicePage();
  else if (state.tab === 'Карта') content = mapPage();
  else if (state.tab === 'Библиотека') content = libraryPage();
  else if (state.tab === 'Профиль') content = profilePage();
  else if (state.tab === 'ИИ-наставник') content = assistantPage();
  else content = home();

  app.innerHTML = `${header()}<main>${content}</main>${nav()}`;
}

function handleClick(event) {
  const button = event.target.closest('button');
  if (!button || !app.contains(button)) return;

  if (button.id === 'theme') {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    save();
    render();
    return;
  }

  if (button.dataset.tab) {
    state.tab = button.dataset.tab;
    state.subject = null;
    state.topic = null;
    render();
    return;
  }

  if (button.dataset.sub) {
    state.subject = button.dataset.sub;
    state.topic = button.dataset.topic === undefined ? null : Number(button.dataset.topic);
    state.tab = 'Науки';
    render();
    return;
  }

  if (button.dataset.topic !== undefined) {
    state.topic = Number(button.dataset.topic);
    render();
    return;
  }

  if (button.id === 'back') {
    if (state.topic !== null) state.topic = null;
    else state.subject = null;
    render();
    return;
  }

  if (button.id === 'done' && state.subject && state.topic !== null) {
    const key = `${state.subject}:${state.topic}`;
    if (!state.completed.includes(key)) state.completed.push(key);
    save();
    state.topic = null;
    render();
    return;
  }

  if (button.dataset.answer !== undefined && state.answers[state.quiz] === undefined) {
    state.answers[state.quiz] = Number(button.dataset.answer);
    save();
    render();
    return;
  }

  if (button.id === 'next' && state.answers[state.quiz] !== undefined) {
    state.quiz = (state.quiz + 1) % quizzes.length;
    render();
  }
}

function handleInput(event) {
  if (event.target.id !== 'search') return;
  const cursor = event.target.selectionStart;
  state.query = event.target.value;
  render();
  const search = $('#search');
  if (search) {
    search.focus();
    search.setSelectionRange(cursor, cursor);
  }
}

async function handleAssistantSubmit(event) {
  if (event.target.id !== 'assistant-form') return;
  event.preventDefault();
  const prompt = $('#assistant-prompt')?.value.trim();
  if (!prompt) return;

  const endpoint = import.meta.env.VITE_AI_API_URL;
  const messages = $('#assistant-messages');
  const status = $('#assistant-status');
  const send = $('#assistant-send');
  if (!endpoint) {
    status.textContent = 'ИИ пока не подключён: сначала нужно развернуть защищённый серверный шлюз и задать VITE_AI_API_URL. API-ключ нельзя помещать в браузерный код.';
    return;
  }

  const userMessage = document.createElement('div');
  userMessage.className = 'assistant-message user';
  userMessage.textContent = prompt;
  messages.append(userMessage);
  $('#assistant-prompt').value = '';
  send.disabled = true;
  status.textContent = 'Наставник готовит ответ…';

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: prompt }),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Ошибка сервера (${response.status})`);
    const answer = document.createElement('div');
    answer.className = 'assistant-message assistant';
    answer.textContent = payload.answer || 'Сервер вернул пустой ответ.';
    messages.append(answer);
    status.textContent = 'Ответ ИИ. Проверяй важные утверждения по первоисточникам.';
  } catch (error) {
    status.textContent = `Не удалось получить ответ: ${error.message}`;
  } finally {
    send.disabled = false;
    messages.scrollTop = messages.scrollHeight;
  }
}

app.addEventListener('click', handleClick);
app.addEventListener('input', handleInput);
app.addEventListener('submit', handleAssistantSubmit);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    const serviceWorkerUrl = `${import.meta.env.BASE_URL}sw.js`;
    navigator.serviceWorker.register(serviceWorkerUrl).catch((error) => {
      console.warn('Офлайн-режим пока недоступен:', error);
    });
  }, { once: true });
}

render();

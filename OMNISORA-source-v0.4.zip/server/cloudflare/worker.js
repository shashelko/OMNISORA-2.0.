const SYSTEM_INSTRUCTION = `Ты — научный ИИ-наставник образовательной платформы OMNISORA. Отвечай на русском языке, ясно и методически: сначала краткий ответ, затем объяснение по шагам, пример и при необходимости проверочный вопрос. Разделяй установленные факты, гипотезы и неопределённость. Не выдумывай источники, DOI, цитаты или результаты исследований. Если вопрос зависит от свежих данных или требует первоисточников, прямо скажи об этом. Не выдавай медицинские, юридические или финансовые догадки за профессиональную консультацию.`;

function corsHeaders(origin, allowedOrigin) {
  const permitted = allowedOrigin === '*' || origin === allowedOrigin;
  return {
    'Access-Control-Allow-Origin': permitted ? (allowedOrigin === '*' ? '*' : allowedOrigin) : 'null',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const cors = corsHeaders(origin, env.ALLOWED_ORIGIN || '');
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    const json = (data, status = 200) => new Response(JSON.stringify(data), {
      status,
      headers: { ...cors, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
    });

    if (request.method !== 'POST') return json({ error: 'Метод не поддерживается.' }, 405);
    if (!env.GEMINI_API_KEY) return json({ error: 'На сервере не задан ключ ИИ.' }, 503);
    if (!env.ALLOWED_ORIGIN || (env.ALLOWED_ORIGIN !== '*' && origin !== env.ALLOWED_ORIGIN)) {
      return json({ error: 'Источник запроса не разрешён.' }, 403);
    }

    let body;
    try { body = await request.json(); } catch { return json({ error: 'Некорректный JSON.' }, 400); }
    const message = typeof body.message === 'string' ? body.message.trim() : '';
    if (!message || message.length > 6000) return json({ error: 'Вопрос должен содержать от 1 до 6000 символов.' }, 400);

    const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    try {
      const upstream = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
          contents: [{ role: 'user', parts: [{ text: message }] }],
          generationConfig: { temperature: 0.45, maxOutputTokens: 1800 },
        }),
      });
      const result = await upstream.json().catch(() => ({}));
      if (!upstream.ok) return json({ error: 'Провайдер ИИ временно не смог обработать запрос.' }, 502);
      const answer = result.candidates?.[0]?.content?.parts?.map((part) => part.text || '').join('\n').trim();
      if (!answer) return json({ error: 'ИИ не вернул текстовый ответ.' }, 502);
      return json({ answer });
    } catch {
      return json({ error: 'Не удалось связаться с провайдером ИИ.' }, 502);
    }
  },
};

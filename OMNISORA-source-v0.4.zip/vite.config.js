import { defineConfig } from 'vite';

// GitHub Actions exposes GITHUB_REPOSITORY as owner/repository.
// Derive the Pages base path from the real repository name instead of a stale slug.
const repository = process.env.GITHUB_REPOSITORY?.split('/')[1];
const pagesBase = repository ? `/${repository}/` : '/';

export default defineConfig({
  base: process.env.GITHUB_ACTIONS === 'true' ? pagesBase : '/',
});

import { defineConfig } from 'vite';

// GitHub Pages serves this repository below /OMNISCIENT-0.1/.
// Local development and other hosts continue to use the root path.
export default defineConfig({
  base: process.env.GITHUB_ACTIONS === 'true' ? '/OMNISCIENT-0.1/' : '/',
});
